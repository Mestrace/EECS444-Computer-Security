//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by keygenerator.rc
//
#define IDD_KEYGENERATOR_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDC_PROJECT                     1000
#define IDC_SELECT                      1001
#define IDC_USERNAME                    1002
#define IDC_GENERATE                    1003
#define IDC_KEYEXPIRATION               1004
#define IDC_EXPIRATION                  1005
#define IDC_HARDWAREID                  1006
#define IDC_KEYDATA                     1007
#define IDC_DATA1                       1008
#define IDC_DATA2                       1009
#define IDC_DATA3                       1010
#define IDC_DATA4                       1011
#define SEPARATOR                       1012
#define IDC_KEY_INTEGERS                1012
#define IDC_INT_1                       1013
#define IDC_INT_2                       1014
#define IDC_INT_3                       1015
#define IDC_INT_4                       1016
#define IDC_INT_5                       1017
#define IDC_INT_6                       1018
#define IDC_INT_7                       1019
#define IDC_INT_8                       1020
#define IDC_CREATION                    1021
#define IDC_KEYCREATION                 1022
#define IDC_INT_9                       1023
#define IDC_INT_10                      1024
#define IDC_INT_11                      1025
#define IDC_INT_12                      1026
#define IDC_INT_13                      1027
#define IDC_INT_14                      1028
#define IDC_INT_15                      1029
#define IDC_INT_16                      1030

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
