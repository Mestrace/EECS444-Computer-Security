
#define	IDI_MAIN	999
#define	DLG_MAIN	111
#define	IDC_REG		120

#define IDB_ENCRYPT_DATA 100
#define IDB_ENCRYPT_MEMORY 102