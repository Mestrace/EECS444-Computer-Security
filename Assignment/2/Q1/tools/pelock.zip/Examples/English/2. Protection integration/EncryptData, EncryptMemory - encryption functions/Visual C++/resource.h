//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by pelock_encryption.rc
//
#define IDD_PELOCK_ENCRYPTION_DIALOG    102
#define IDR_MAINFRAME                   128
#define IDC_ENCRYPTION                  1000
#define IDC_ENCRYPT_DATA                1001
#define IDC_ENCRYPT_MEMORY              1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
