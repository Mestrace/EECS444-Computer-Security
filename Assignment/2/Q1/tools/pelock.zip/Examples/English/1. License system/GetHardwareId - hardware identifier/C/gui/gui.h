
#define	IDI_MAIN	999
#define	DLG_MAIN	111
#define	IDC_REG		120
#define	IDC_HARDWARE_ID	124