#define UNICODE

#include <windows.h>
#include <tchar.h>
#include <stdio.h>
#include <conio.h>
#include "pelock.h"